import React from 'react';

class CustomImage extends React.Component {

    render() {
        return(
            <div>
                <img src="./images/unnamed.GIF  " alt="mohit"width="500px" height="100px"/>
            </div>
        )
    }
}
export default CustomImage