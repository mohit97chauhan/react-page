import React from 'react'

class SignIn extends React.Component {
    render() {
        return (
            <p>SignIn</p>
        )
    }
}

export default SignIn